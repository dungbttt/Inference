# GENERATED VERSION FILE
# TIME: Mon Jul 31 11:40:06 2023
__version__ = '1.2.0+cc63400'
short_version = '1.2.0'
version_info = (1, 2, 0)
